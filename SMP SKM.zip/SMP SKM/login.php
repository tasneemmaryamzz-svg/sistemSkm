<?php
// proses/login.php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = trim($_POST['id_pengguna']);
    $kata = $_POST['kata_laluan'];

    if (!is_numeric($id)) {
        echo "<script>alert('ID mesti nombor!'); window.location='index.php';</script>";
        exit;
    }

    $id = (int)$id;

    // Hash kata laluan (untuk banding dengan database)
    // Dalam contoh, semua kata laluan adalah 'admin123' → hash sama
    $hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

    // 1. SEMAK ADMIN
    $sql = "SELECT id, nama_penuh FROM admin WHERE id = ? AND kata_laluan = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $id, $hash);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nama_penuh'] = $user['nama_penuh'];
        $_SESSION['role'] = 'admin';
        header("Location:dashboard.php");
        exit;
    }

    // 2. SEMAK PENSARAH
    $sql = "SELECT id, nama_penuh FROM pensyarah WHERE id = ? AND kata_laluan = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $id, $hash);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nama_penuh'] = $user['nama_penuh'];
        $_SESSION['role'] = 'pensyarah';
        header("Location:dashboard.php");
        exit;
    }

    // 3. SEMAK PELAJAR
    $sql = "SELECT id, nama_pelajar FROM pelajar WHERE id = ? AND kata_laluan = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $id, $hash);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nama_penuh'] = $user['nama_pelajar'];
        $_SESSION['role'] = 'pelajar';
        header("Location:dashboard.php");
        exit;
    }

    echo "<script>alert('ID atau kata laluan salah!'); window.location='index.php';</script>";
}
?>