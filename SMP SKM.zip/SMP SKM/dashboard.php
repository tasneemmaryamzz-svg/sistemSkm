<?php
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'];
$nama = $_SESSION['nama_penuh'];
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - SMP SKM</title>
    <style>
        body { font-family: Arial; background: #f0f8ff; padding: 20px; }
        .card { max-width: 600px; margin: 40px auto; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center; }
        .btn { display: block; width: 80%; margin: 12px auto; padding: 15px; background: #9370db; color: white; text-decoration: none; border-radius: 8px; font-weight: bold; }
        .btn:hover { background: #7a5db8; }
        .logout { background: #dc3545; }
        h1 { color: #333; }
        h2 { color: #9370db; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Selamat Datang</h1>
        <h2><?= htmlspecialchars($nama) ?></h2>
        <p><strong>Peranan:</strong> <?= ucfirst($role) ?></p>
        <hr>

        <?php if ($role == 'admin'): ?>
            <a href="#" class="btn">1.0 Pengurusan Pengguna</a>
            <a href="#" class="btn">2.0 Daftar Pensyarah</a>
            <a href="#" class="btn">6.0 Daftar Pelajar</a>
            <a href="#" class="btn">10.0 Daftar Kursus</a>
            <a href="#" class="btn">17.0 Jana Laporan</a>
            <a href="#" class="btn">20.0 Edit Sistem</a>

        <?php elseif ($role == 'pensyarah'): ?>
            <a href="#" class="btn">3.0 Kemaskini Pensyarah</a>
            <a href="#" class="btn">7.0 Kemaskini Pelajar</a>
            <a href="#" class="btn">14.0 Masukkan SKM</a>

        <?php elseif ($role == 'pelajar'): ?>
            <a href="#" class="btn">Lihat Maklumat Saya</a>
            <a href="#" class="btn">Lihat Markah SKM</a>
        <?php endif; ?>

        <br>
        <a href="logout.php" class="btn logout">Log Keluar</a>
    </div>
</body>
</html>