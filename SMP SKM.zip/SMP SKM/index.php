<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Masuk - SMP SKM</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { background: #f0f8ff; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .container { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); width: 100%; max-width: 500px; text-align: center; }
        .logo { width: 80px; height: 80px; background: black; border-radius: 50%; margin: 0 auto 20px; position: relative; }
        .logo::after { content: ''; width: 30px; height: 30px; background: white; border-radius: 50%; position: absolute; top: 25px; left: 25px; }
        h1 { font-size: 24px; margin-bottom: 8px; color: #333; }
        h2 { font-size: 36px; color: #9370db; margin-bottom: 30px; font-weight: bold; }
        .login-box { background: #f8f9fa; padding: 30px; border-radius: 15px; margin-top: 20px; }
        .login-box h3 { color: #9370db; margin-bottom: 20px; font-size: 20px; }
        .input-group { position: relative; margin-bottom: 20px; text-align: left; }
        .input-group label { display: block; margin-bottom: 5px; color: #666; font-size: 14px; }
        .input-group input { width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 8px; background: #f0f8ff; font-size: 16px; }
        .forgot { text-align: right; margin-bottom: 20px; }
        .forgot a { color: #007bff; text-decoration: underline; font-size: 13px; }
        .btn-login { background: #708090; color: white; border: none; padding: 12px; width: 100%; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; }
        .btn-login:hover { background: #5f6a7a; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo"></div>
        <h1>Sistem Maklumat Pelajar SKM</h1>
        <h2>SMP SKM</h2>

        <div class="login-box">
            <h3>LOG IN</h3>
            <form action="login.php" method="POST">
                <div class="input-group">
                    <label>ID</label>
                    <input type="text" name="id_pengguna" placeholder="Contoh: 1, 100, 1001" required>
                </div>
                <div class="input-group">
                    <label>Kata Laluan</label>
                    <input type="password" name="kata_laluan" required>
                </div>
                <div class="forgot">
                    <a href="#">Lupa kata laluan?</a>
                </div>
                <button type="submit" class="btn-login">LOG MASUK</button>
            </form>
        </div>
    </div>
</body>
</html>