CREATE DATABASE IF NOT EXISTS smp_skm;
USE smp_skm;

-- ADMIN
CREATE TABLE admin (
    id INT PRIMARY KEY,
    kata_laluan VARCHAR(255) NOT NULL,
    nama_penuh VARCHAR(100) NOT NULL
);

-- PENSARAH
CREATE TABLE pensyarah (
    id INT PRIMARY KEY,
    kata_laluan VARCHAR(255) NOT NULL,
    nama_penuh VARCHAR(100) NOT NULL,
    jabatan VARCHAR(50)
);

-- PELAJAR
CREATE TABLE pelajar (
    id INT PRIMARY KEY,
    kata_laluan VARCHAR(255) NOT NULL,
    nama_pelajar VARCHAR(100) NOT NULL,
    kelas VARCHAR(10),
    ic VARCHAR(20)
);

-- CONTOH DATA (Kata laluan: admin123)
INSERT INTO admin (id, kata_laluan, nama_penuh) VALUES
(1, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Pentadbir Sistem');

INSERT INTO pensyarah (id, kata_laluan, nama_penuh, jabatan) VALUES
(100, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Cikgu Ali', 'Sains Komputer');

INSERT INTO pelajar (id, kata_laluan, nama_pelajar, kelas, ic) VALUES
(1001, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ali Bin Abu', '5A', '000101-01-0001');