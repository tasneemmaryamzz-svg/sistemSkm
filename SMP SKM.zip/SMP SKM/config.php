<?php
// config.php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'smp_skm';

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Sambungan gagal: " . $conn->connect_error);
}

// Pastikan sesi bermula
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>